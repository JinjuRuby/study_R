df <- head(quakes, 100)
gc <- data.frame(lon=df$long, lat=df$lat)
